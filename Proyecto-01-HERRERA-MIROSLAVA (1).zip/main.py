from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

from users_file import users_platform

user= input ("Ingresa tu usuario: ")
password= input("Ingresa tu password: ")
auth = 0
ventas = 0
vendido = []
search = 0
seek = []
resena = 0
count = 0
calificacion = []
pres = 0
inc = 0
ventames = [[0,0,0,0,0,0,0,0,0,0,0,0],[1,2,3,4,5,6,7,8,9,10,11,12]]
for userC in users_platform:
    
    if userC[0]==user and userC[1]==password:
        auth = 1
        break
    else:
        auth = 0

if auth == 1:
    print("Acceso validado")
    
    opcionreporte=input("Ingresa la opción del reporte que requieras ver""\n" "1.TOP 50 sales""\n""2.Los más buscados""\n""3.Menos vendidos""\n""4.Los menos buscado""\n""5.los 20 favoritos""\n""6.Los menos favoritos""\n""7.Total Ingresos""\n""8.Promedio mensual""\n""9. meses con mas ventas")
   
    if opcionreporte == "1":
        #PRODUCTOS MÁS VENDIDOS
        for producto in lifestore_products:
            for venta in lifestore_sales:
                
                if producto[0] == venta [1]:
                    ventas+=1
            vendido.append([producto[0], producto[1], ventas])
            ventas = 0

        def sort_key(row):
            return row[2]
        vendido.sort(key = sort_key) 
        vendido.reverse()
   
        for total in range(0,49):
            if vendido[total][2] != 0:
                print("El producto:", vendido[total][1],
                      "\n""Total de ventas:", vendido[total][2])
                
    if opcionreporte == "2":
    #PRODUCTOS MÁS BUSCADOS
        for producto in lifestore_products:
            for busqueda in lifestore_searches:
                #PRODUCTO EN POS 0 ES EL ID QUE ES IGUAL A VENTA EN POS 1
                if producto[0] == busqueda [1]:
                    search+=1
            seek.append([producto[0], producto[1], search])
            search = 0

        def sort_key(row):
            return row[2]
        seek.sort(key = sort_key) 
        seek.reverse()
   
        for total in range(0,49):
            if seek[total][2] != 0:
                print("El producto:", seek[total][1],
                      "\n""Total de búsquedas:", seek[total][2])
    
    if opcionreporte == "3":
        #PRODUCTOS MENOS VENDIDOS
        for producto in lifestore_products:
            for venta in lifestore_sales:
                if producto[0] == venta [1]:
                    ventas+=1
            vendido.append([producto[0], producto[1], ventas])
            ventas = 0

        def sort_key(row):
            return row[2]
        vendido.sort(key = sort_key) 
   
        for total in range(0,49):
                print("El producto:", vendido[total][1],
                      "\n""Total de ventas:", vendido[total][2])
        
    if opcionreporte == "4":
        #PRODUCTOS MENOS BUSCADOS
        for producto in lifestore_products:
            for busqueda in lifestore_searches:
                #PRODUCTO EN POS 0 ES EL ID QUE ES IGUAL A VENTA EN POS 1
                if producto[0] == busqueda [1]:
                    search+=1
            seek.append([producto[0], producto[1], search])
            search = 0

        def sort_key(row):
            return row[2]
        seek.sort(key = sort_key) 
   
        for total in range(0,49):
            print("El producto:", seek[total][1],
                  "\n""Total de búsquedas:", seek[total][2])
            
    if opcionreporte == "5":
        #PRODUCTOS MEJORES RESEÑAS
        for producto in lifestore_products:
            for res in lifestore_sales:
                #PRODUCTO EN POS 0 ES EL ID QUE ES IGUAL A VENTA EN POS 1
                if producto[0] == res [1]:
                    resena = resena + res[2]
                    count+=1
            if count !=0:
                pres = resena/count
            else:
                pres = 0
                
            calificacion.append([producto[0], producto[1], pres])
            count = 0
            resena = 0
            pres = 0

        def sort_key(row):
            return row[2]
        calificacion.sort(key = sort_key) 
        calificacion.reverse()
   
        for total in range(0,19):
            print("El producto:", calificacion[total][1],
                  "\n""Rating promedio:", calificacion[total][2])
        
    if opcionreporte == "6":
        #PRODUCTOS PEORES RESEÑAS
        for producto in lifestore_products:
            for res in lifestore_sales:
                #PRODUCTO EN POS 0 ES EL ID QUE ES IGUAL A VENTA EN POS 1
                if producto[0] == res [1] and res[4] == 1:
                    resena = resena + res[2]
                    count+=1
                    if count !=0:
                        pres = resena/count
                    else:
                        pres = 0
                
                    calificacion.append([producto[0], producto[1], pres])
            count = 0
            resena = 0
            pres = 0

        def sort_key(row):
            return row[2]
        calificacion.sort(key = sort_key) 
   
        for total in range(0,4):
            print("El producto:", calificacion[total][1],
                  "\n""Rating promedio:", calificacion[total][2])
        
    if opcionreporte == "7":
        #INGRESO TOTAL
        for producto in lifestore_products:
            for venta in lifestore_sales:
                
                if producto[0] == venta [1]:
                    ventas+=1
            inc = inc + producto[2]*ventas
            ventas = 0

        print("INGRESO TOTAL:", inc)
        
    if opcionreporte == "8": 
        #INGRESO TOTAL
        for producto in lifestore_products:
            for venta in lifestore_sales:
                
                if producto[0] == venta [1]:
                    ventas+=1
            inc = inc + producto[2]*ventas
            ventas = 0

        print("VENTA PROMEDIO MENSUAL:", (inc/12))
        
    if opcionreporte == "9":
        #MESES CON MÁS ITEMS VENDIDOS
        for producto in lifestore_products:
            for venta in lifestore_sales:
                for count in range(1,12):
                    mes = venta[3]
                    if producto[0] == venta [1] and int(mes[3:5]) == count:
                        ventames[0][count-1] = ventames[0][count-1] + 1 
   
        for mes in range(1,13):
            print("El mes:", mes,
             "\n""se vendió un total de:", ventames[0][mes-1],"items")

           
if auth == 0:
    print("sin acceso")